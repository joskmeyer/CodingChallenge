from django.contrib import admin
from .models import short_url


# Register your models here.
admin.site.register(short_url)