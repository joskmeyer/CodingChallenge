from django.db import models

# Create the table for the database

class short_url(models.Model):
    id = models.IntegerField(primary_key=True)
    long_url = models.CharField(max_length = 200)
    segment = models.CharField(max_length = 25)

    def __str__(self):
        return self.segment