from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name='index'),
    path('short_url/<int:id>', views.short_url_by_id,name='short_url_by_id'),
    path('creation',views.short_url_creation, name='short_url_creation'),
    path('<str:s_url>',views.urlRedirect, name="redirect")
]





#urlpatterns = [
#    path('',views.index,name='index'),
#    path('short_url/<int:id>', views.short_url_by_id,name='short_url_by_id'),
##    path('creation',views.short_url_creation, name='short_url_creation'),
#    path('<str:s_url>',views.urlRedirect, name="redirect")
#]