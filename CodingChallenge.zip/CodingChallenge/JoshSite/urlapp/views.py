from django.shortcuts import render
from django.http import HttpResponse
from .models import short_url
import validators
import random
import string
from django.shortcuts import redirect

def index(request):
    return HttpResponse("Welcome to Josh Site. This page is unfinished at the time of you entering. Please add the suffix '/creation' to the URL in order to get to the main functionality.")



#test function to ensure database is saving properly
def short_url_by_id(request, id):
    s_url = short_url.objects.get(pk=id)

    return render(request, 'details.html', {'short_url':s_url})



def short_url_creation(request):

    #get contents of database to display back to user
    query_results = short_url.objects.all()

    #Requirement #1: Given a Long URL and short URL save
    if request.POST.get('long_url') and request.POST.get('short_url'):
        post = short_url()
        post.long_url = request.POST.get('long_url')
        post.segment = request.POST.get('short_url')
        post.save()

        return render(request, 'createurl.html',{'query_results':query_results})

    #Requirements #2: Givent a Long URL generate a short URL and save
    if request.POST.get('long_url_shorten'):
        post = short_url()
        post.long_url = request.POST.get('long_url_shorten')
        post.segment = shorten(post.long_url)
        if len(post.segment) > 0 and post.long_url:
            post.save()

        return render(request, 'createurl.html', {'query_results': query_results})
    else:
        return render(request, 'createurl.html', {'query_results':query_results})


def shorten(s):
    #won't run if not a valid url
    valid = validators.url(s)
    to_return=''
    if valid:
        for i in range(0,10): #generate random letters for short url generation
            to_return+= random.choice(string.ascii_letters)

    return to_return


#given a short URL, look up the object in the database and then return a redirect to the long URL
def urlRedirect(request, s_url):
    redirect_url = short_url.objects.get(segment=s_url)
    return redirect(redirect_url.long_url)

